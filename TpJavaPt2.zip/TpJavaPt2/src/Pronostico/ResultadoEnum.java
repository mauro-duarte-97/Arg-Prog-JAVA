package Pronostico;

public enum ResultadoEnum {
    GANADOR, PERDEDOR, EMPATE
}
